package com.example.SoporteTecnico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoporteTecnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
