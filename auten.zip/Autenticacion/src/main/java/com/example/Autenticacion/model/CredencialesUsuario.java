package com.example.Autenticacion.model;

import lombok.Data;

@Data
public class CredencialesUsuario {

    private String username;
    private String password;

}
