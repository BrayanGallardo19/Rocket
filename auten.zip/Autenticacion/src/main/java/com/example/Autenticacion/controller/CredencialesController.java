package com.example.Autenticacion.controller;

import com.example.credenciales.service.AuthService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

public class CredencialesController {
    @Autowired
    private AutenticacionService auService;

    @PostMapping("/login")
    public Mono<String> login(@RequestBody AuthRequest request) {
        return auService.autenticar(request.getUsername(), request.getPassword())
                .map(valid -> valid ? "Autenticación exitosa" : "Credenciales inválidas");
    }

    @Data
    public static class AuthRequest {
        private String username;
        private String password;
    }
}
