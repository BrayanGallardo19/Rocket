package com.example.Autenticacion.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Autenticacion.configuration.WebClientConfig;
import com.example.Autenticacion.model.CredencialesUsuario;

public class AutenticacionService {

        @Autowired
    private WebClientConfig webClient;

    public Mono<Boolean> autenticar(String username, String password) {
        return webClient.get()
                .uri("/api/usuarios/{username}", username)
                .retrieve()
                .bodyToMono(CredencialesUsuario.class)
                .map(usuario -> usuario.getPassword().equals(password))
                .onErrorReturn(false); // Si el usuario no existe o hay error, retornar false
    }


}
