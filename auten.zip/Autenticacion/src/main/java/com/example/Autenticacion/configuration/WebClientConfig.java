package com.example.Autenticacion.configuration;

import org.springframework.boot.autoconfigure.web.reactive.function.client.WebClientSsl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class WebClientConfig {
    @Bean
    public WebClientSsl webClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8081") // URL del microservicio de usuarios
                .build();
    }
}
