package com.example.Autenticacion.repository;

public class AutenticacionRepository {

  
}
