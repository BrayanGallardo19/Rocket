package com.example.Autenticacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
